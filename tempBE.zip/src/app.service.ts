import { Injectable } from '@nestjs/common';
import { quotes } from './quotes';
import { M } from 'vite/dist/node/types.d-aGj9QkWt';
import { stringify } from 'querystring';

@Injectable()
export class AppService {
  getQuotes() {
    return quotes.quotes;
  }
  getRandomQuotes() {
    let id = Math.floor(Math.random() * (quotes.quotes.length)) + 0;
    return quotes.quotes[id];
  }
  getTopQuotes(){
    let quotesList = quotes.quotes;
    const frequencyMap = new Map();

    quotesList.forEach(e => {
      let count = frequencyMap.get(e.author) || 0;
      frequencyMap.set(e.author,count+1);
    });

    const sortedItems = Array.from(frequencyMap.entries()).sort((a, b) => b[1] - a[1]);

    return sortedItems;
  }
}
