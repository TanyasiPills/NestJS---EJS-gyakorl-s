import { Controller, Get, Render } from '@nestjs/common';
import { AppService } from './app.service';
import { quotes } from './quotes';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  @Get('quotes')
  @Render('quotes')
  getQuote() {
    return {
      quotes: this.appService.getQuotes()
    };
  }
  @Get('randomQuote')
  @Render('rand')
  getRanQuote() {
    return {
      quote: this.appService.getRandomQuotes()
    };
  }
  @Get('topAuthors')
  @Render('top')
  getTopAuthor() {
    return {
      quote: this.appService.getTopQuotes()
    };
  }
}
